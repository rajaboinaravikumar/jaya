import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PublicHeader } from "@/components/PublicHeader";
import { Footer } from "@/components/Footer";
import { CheckCircle2, Upload, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdmissionsPortal() {
  const [currentStep, setCurrentStep] = useState(1);
  const { toast } = useToast();

  const steps = [
    { number: 1, title: 'Personal Info' },
    { number: 2, title: 'Academic Details' },
    { number: 3, title: 'Documents' },
    { number: 4, title: 'Payment' },
  ];

  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Admissions', href: '/admissions' },
    { label: 'Contact', href: '/contact' },
  ];

  const footerSections = [
    {
      title: 'Quick Links',
      links: [
        { label: 'About Us', href: '/about' },
        { label: 'Programs', href: '/programs' },
      ],
    },
  ];

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    } else {
      toast({
        title: "Application Submitted!",
        description: "Your application has been successfully submitted. We'll contact you soon.",
      });
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <div className="min-h-screen">
      <PublicHeader
        navLinks={navLinks}
        onNavClick={(href) => console.log('Navigate:', href)}
        onLoginClick={() => console.log('Login')}
      />

      <div className="max-w-4xl mx-auto px-6 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Apply to JITS University</h1>
          <p className="text-muted-foreground text-lg">
            Complete your application in a few simple steps
          </p>
        </div>

        <div className="mb-8">
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors ${
                      currentStep >= step.number
                        ? 'bg-primary border-primary text-primary-foreground'
                        : 'border-muted-foreground/30 text-muted-foreground'
                    }`}
                  >
                    {currentStep > step.number ? (
                      <CheckCircle2 className="h-6 w-6" />
                    ) : (
                      step.number
                    )}
                  </div>
                  <span className="text-sm mt-2 hidden md:block">{step.title}</span>
                </div>
                {index < steps.length - 1 && (
                  <div
                    className={`h-0.5 flex-1 transition-colors ${
                      currentStep > step.number ? 'bg-primary' : 'bg-muted-foreground/30'
                    }`}
                  />
                )}
              </div>
            ))}
          </div>
        </div>

        <Card className="p-8">
          {currentStep === 1 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold mb-6">Personal Information</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" placeholder="John" data-testid="input-firstname" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" placeholder="Doe" data-testid="input-lastname" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="john@example.com" data-testid="input-email" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" type="tel" placeholder="+1 234 567 8900" data-testid="input-phone" />
                </div>
              </div>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold mb-6">Academic Details</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="program">Program</Label>
                  <Select>
                    <SelectTrigger data-testid="select-program">
                      <SelectValue placeholder="Select program" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cs">Computer Science</SelectItem>
                      <SelectItem value="ee">Electrical Engineering</SelectItem>
                      <SelectItem value="me">Mechanical Engineering</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="level">Level</Label>
                  <Select>
                    <SelectTrigger data-testid="select-level">
                      <SelectValue placeholder="Select level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ug">Undergraduate</SelectItem>
                      <SelectItem value="pg">Postgraduate</SelectItem>
                      <SelectItem value="phd">PhD</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gpa">Previous GPA</Label>
                  <Input id="gpa" placeholder="3.8" data-testid="input-gpa" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Year of Completion</Label>
                  <Input id="year" placeholder="2024" data-testid="input-year" />
                </div>
              </div>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold mb-6">Upload Documents</h2>
              <div className="space-y-4">
                {['Academic Transcripts', 'ID Proof', 'Passport Photo'].map((doc) => (
                  <div key={doc} className="border-2 border-dashed rounded-lg p-6 text-center hover-elevate cursor-pointer">
                    <Upload className="h-8 w-8 mx-auto mb-3 text-muted-foreground" />
                    <h4 className="font-medium mb-1">{doc}</h4>
                    <p className="text-sm text-muted-foreground">Click to upload or drag and drop</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold mb-6">Payment</h2>
              <div className="bg-muted/30 p-6 rounded-lg mb-6">
                <div className="flex justify-between mb-2">
                  <span>Application Fee</span>
                  <span className="font-semibold">$50.00</span>
                </div>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Processing Fee</span>
                  <span>$5.00</span>
                </div>
                <div className="border-t mt-4 pt-4 flex justify-between text-lg font-bold">
                  <span>Total</span>
                  <span>$55.00</span>
                </div>
              </div>
              <Button className="w-full" size="lg" data-testid="button-proceed-payment">
                <CreditCard className="mr-2 h-5 w-5" />
                Proceed to Payment
              </Button>
            </div>
          )}

          <div className="flex justify-between mt-8 pt-6 border-t">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 1}
              data-testid="button-back"
            >
              Back
            </Button>
            <Button onClick={handleNext} data-testid="button-next">
              {currentStep === 4 ? 'Submit Application' : 'Next'}
            </Button>
          </div>
        </Card>
      </div>

      <Footer sections={footerSections} onLinkClick={(href) => console.log('Navigate:', href)} />
    </div>
  );
}
