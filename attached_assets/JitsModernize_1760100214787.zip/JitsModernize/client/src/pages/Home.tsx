import { HeroSection } from "@/components/HeroSection";
import { QuickLinks } from "@/components/QuickLinks";
import { AnnouncementCarousel } from "@/components/AnnouncementCarousel";
import { StatsSection } from "@/components/StatsSection";
import { NotificationBar } from "@/components/NotificationBar";
import { PublicHeader } from "@/components/PublicHeader";
import { Footer } from "@/components/Footer";
import { GraduationCap, FileText, Calendar, Users, BookOpen, Award, Building } from "lucide-react";
import heroImage from '@assets/stock_images/diverse_university_s_72fb7dec.jpg';
import buildingImage from '@assets/stock_images/modern_university_bu_30b47520.jpg';
import classroomImage from '@assets/stock_images/university_classroom_72133f0d.jpg';

export default function Home() {
  const navLinks = [
    { label: 'Home', href: '/' },
    {
      label: 'Academics',
      href: '/academics',
      subItems: [
        { label: 'Departments', href: '/departments' },
        { label: 'Programs', href: '/programs' },
        { label: 'Faculty', href: '/faculty' },
      ],
    },
    { label: 'Admissions', href: '/admissions' },
    { label: 'Alumni', href: '/alumni' },
    { label: 'Contact', href: '/contact' },
  ];

  const quickLinks = [
    {
      icon: GraduationCap,
      title: 'Admissions',
      description: 'Apply online and track your application status',
      href: '/admissions',
    },
    {
      icon: FileText,
      title: 'Results',
      description: 'View exam results and academic performance',
      href: '/results',
    },
    {
      icon: Calendar,
      title: 'Academic Calendar',
      description: 'Stay updated with important dates',
      href: '/calendar',
    },
    {
      icon: Users,
      title: 'Alumni',
      description: 'Connect with our alumni network',
      href: '/alumni',
    },
  ];

  const announcements = [
    {
      id: '1',
      date: 'Oct 10, 2025',
      title: 'Fall 2026 Admissions Now Open',
      description: 'Apply now for Fall 2026 semester. Early bird discounts available until November 30th. Don\'t miss this opportunity to join our community of excellence.',
      image: buildingImage,
      category: 'Admissions',
    },
    {
      id: '2',
      date: 'Oct 8, 2025',
      title: 'Annual Tech Fest 2025',
      description: 'Join us for three days of innovation, workshops, and competitions. Register before Oct 20th. Amazing prizes and opportunities to showcase your talent.',
      image: classroomImage,
      category: 'Events',
    },
    {
      id: '3',
      date: 'Oct 5, 2025',
      title: 'New AI & Machine Learning Lab Inaugurated',
      description: 'State-of-the-art AI lab with latest GPU systems now available for student research projects. Book your slots for cutting-edge research.',
      category: 'Infrastructure',
    },
  ];

  const stats = [
    {
      value: '15,000+',
      label: 'Students Enrolled',
      icon: <Users className="h-8 w-8" />,
    },
    {
      value: '250+',
      label: 'Expert Faculty',
      icon: <BookOpen className="h-8 w-8" />,
    },
    {
      value: '95%',
      label: 'Placement Rate',
      icon: <Award className="h-8 w-8" />,
    },
    {
      value: '50+',
      label: 'Partner Companies',
      icon: <Building className="h-8 w-8" />,
    },
  ];

  const footerSections = [
    {
      title: 'Quick Links',
      links: [
        { label: 'About Us', href: '/about' },
        { label: 'Admissions', href: '/admissions' },
        { label: 'Careers', href: '/careers' },
      ],
    },
    {
      title: 'Resources',
      links: [
        { label: 'Library', href: '/library' },
        { label: 'Academic Calendar', href: '/calendar' },
        { label: 'Student Portal', href: '/portal' },
      ],
    },
    {
      title: 'Support',
      links: [
        { label: 'Contact Us', href: '/contact' },
        { label: 'FAQ', href: '/faq' },
        { label: 'Support', href: '/support' },
      ],
    },
  ];

  const handleNavigation = (href: string) => {
    console.log('Navigate to:', href);
  };

  const handleLogin = () => {
    console.log('Login clicked');
  };

  return (
    <div className="min-h-screen">
      <NotificationBar
        message="Exam results for Fall 2025 semester will be published on October 15th at 10:00 AM"
        type="info"
      />
      <PublicHeader
        navLinks={navLinks}
        onNavClick={handleNavigation}
        onLoginClick={handleLogin}
      />
      <HeroSection
        title="Welcome to JITS University"
        subtitle="Empowering minds, shaping futures. Join a community of excellence in education and innovation."
        primaryCta="Apply Now"
        secondaryCta="Virtual Tour"
        backgroundImage={heroImage}
        onPrimaryClick={() => handleNavigation('/admissions')}
        onSecondaryClick={() => handleNavigation('/tour')}
      />
      <QuickLinks links={quickLinks} onLinkClick={handleNavigation} />
      <AnnouncementCarousel announcements={announcements} />
      <StatsSection stats={stats} />
      <Footer sections={footerSections} onLinkClick={handleNavigation} />
    </div>
  );
}
