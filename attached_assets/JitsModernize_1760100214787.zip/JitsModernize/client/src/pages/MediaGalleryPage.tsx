import { MediaGallery } from "@/components/MediaGallery";
import { PublicHeader } from "@/components/PublicHeader";
import { Footer } from "@/components/Footer";
import { SearchBar } from "@/components/SearchBar";
import { Button } from "@/components/ui/button";
import campusImage1 from '@assets/stock_images/diverse_university_s_f630801d.jpg';
import campusImage2 from '@assets/stock_images/diverse_university_s_e86df4b4.jpg';
import buildingImage1 from '@assets/stock_images/modern_university_bu_30b47520.jpg';
import buildingImage2 from '@assets/stock_images/modern_university_bu_2f8d4032.jpg';
import classroomImage1 from '@assets/stock_images/university_classroom_72133f0d.jpg';
import classroomImage2 from '@assets/stock_images/university_classroom_9ea92665.jpg';

export default function MediaGalleryPage() {
  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Gallery', href: '/gallery' },
  ];

  const footerSections = [
    {
      title: 'Quick Links',
      links: [
        { label: 'Home', href: '/' },
        { label: 'Contact', href: '/contact' },
      ],
    },
  ];

  const galleryItems = [
    { id: '1', src: campusImage1, alt: 'Students collaborating on campus', category: 'Campus Life' },
    { id: '2', src: buildingImage1, alt: 'Modern university building', category: 'Infrastructure' },
    { id: '3', src: classroomImage1, alt: 'Interactive classroom session', category: 'Academics' },
    { id: '4', src: campusImage2, alt: 'Campus activities and events', category: 'Events' },
    { id: '5', src: buildingImage2, alt: 'University facilities', category: 'Infrastructure' },
    { id: '6', src: classroomImage2, alt: 'Learning environment', category: 'Academics' },
  ];

  const categories = ['All', 'Campus Life', 'Infrastructure', 'Academics', 'Events'];

  return (
    <div className="min-h-screen">
      <PublicHeader
        navLinks={navLinks}
        onNavClick={(href) => console.log('Navigate:', href)}
        onLoginClick={() => console.log('Login')}
      />

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-4">Campus Gallery</h1>
          <p className="text-muted-foreground text-lg mb-8">
            Explore our vibrant campus life and state-of-the-art facilities
          </p>

          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex gap-2 flex-wrap">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant="outline"
                  size="sm"
                  data-testid={`filter-${category.toLowerCase()}`}
                >
                  {category}
                </Button>
              ))}
            </div>
            <SearchBar
              placeholder="Search gallery..."
              className="w-full md:w-64"
              onSearch={(query) => console.log('Search:', query)}
            />
          </div>
        </div>

        <MediaGallery items={galleryItems} />
      </div>

      <Footer sections={footerSections} onLinkClick={(href) => console.log('Navigate:', href)} />
    </div>
  );
}
