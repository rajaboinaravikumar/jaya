import { DashboardCard } from "@/components/DashboardCard";
import { SearchBar } from "@/components/SearchBar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { BookOpen, Calendar, DollarSign, FileText, Bell, User } from "lucide-react";
import { ThemeToggle } from "@/components/ThemeToggle";
import studentAvatar from '@assets/stock_images/professional_headsho_19d9c43c.jpg';

export default function StudentDashboard() {
  const assignments = [
    { id: 1, title: 'Data Structures Assignment 3', course: 'CS301', dueDate: 'Oct 15, 2025', status: 'pending' },
    { id: 2, title: 'Database Project Report', course: 'CS402', dueDate: 'Oct 18, 2025', status: 'pending' },
    { id: 3, title: 'Web Development Lab', course: 'CS305', dueDate: 'Oct 12, 2025', status: 'submitted' },
  ];

  const recentGrades = [
    { course: 'Operating Systems', grade: 'A', credits: 4 },
    { course: 'Computer Networks', grade: 'A-', credits: 3 },
    { course: 'Machine Learning', grade: 'B+', credits: 3 },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b">
        <div className="flex items-center justify-between px-6 h-16">
          <h1 className="text-xl font-bold text-primary">JITS Portal</h1>
          <div className="flex items-center gap-4">
            <SearchBar
              placeholder="Search courses, assignments..."
              className="w-64 hidden md:block"
              onSearch={(query) => console.log('Search:', query)}
            />
            <Button variant="ghost" size="icon" data-testid="button-notifications">
              <Bell className="h-5 w-5" />
            </Button>
            <ThemeToggle />
            <Avatar data-testid="avatar-user">
              <AvatarImage src={studentAvatar} />
              <AvatarFallback><User className="h-5 w-5" /></AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Welcome back, Sarah!</h2>
          <p className="text-muted-foreground">Here's what's happening with your studies</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4 mb-8">
          <DashboardCard
            title="Attendance"
            value="92.5%"
            icon={BookOpen}
            description="This semester"
            accentColor="bg-success"
          />
          <DashboardCard
            title="Current GPA"
            value="3.8"
            icon={BookOpen}
            trend={{ value: '+0.2 from last sem', isPositive: true }}
            accentColor="bg-primary"
          />
          <DashboardCard
            title="Pending Assignments"
            value="3"
            icon={FileText}
            description="Due this week"
            accentColor="bg-warning"
          />
          <DashboardCard
            title="Fee Status"
            value="Paid"
            icon={DollarSign}
            description="Next due: Dec 2025"
            accentColor="bg-info"
          />
        </div>

        <div className="grid gap-6 lg:grid-cols-2 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">Recent Assignments</h3>
              <Button variant="ghost" size="sm" data-testid="button-view-all-assignments">View All</Button>
            </div>
            <div className="space-y-4">
              {assignments.map((assignment) => (
                <div key={assignment.id} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">{assignment.title}</h4>
                    <p className="text-sm text-muted-foreground">{assignment.course}</p>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Due</p>
                      <p className="text-sm font-medium">{assignment.dueDate}</p>
                    </div>
                    <Badge variant={assignment.status === 'pending' ? 'default' : 'secondary'}>
                      {assignment.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold">Recent Grades</h3>
              <Button variant="ghost" size="sm" data-testid="button-view-all-grades">View All</Button>
            </div>
            <div className="space-y-4">
              {recentGrades.map((grade, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-muted/30 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium mb-1">{grade.course}</h4>
                    <p className="text-sm text-muted-foreground">{grade.credits} credits</p>
                  </div>
                  <div className="text-2xl font-bold text-primary">{grade.grade}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>

        <Card className="p-6">
          <h3 className="text-xl font-semibold mb-6">This Week's Schedule</h3>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {['Monday', 'Tuesday', 'Wednesday'].map((day) => (
              <div key={day} className="p-4 bg-muted/30 rounded-lg">
                <h4 className="font-medium mb-3">{day}</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>9:00 AM - Database Systems</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span>2:00 PM - Web Technologies</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </main>
    </div>
  );
}
