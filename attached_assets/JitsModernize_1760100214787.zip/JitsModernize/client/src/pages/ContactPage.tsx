import { ContactForm } from "@/components/ContactForm";
import { PublicHeader } from "@/components/PublicHeader";
import { Footer } from "@/components/Footer";
import { Card } from "@/components/ui/card";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

export default function ContactPage() {
  const navLinks = [
    { label: 'Home', href: '/' },
    { label: 'Contact', href: '/contact' },
  ];

  const footerSections = [
    {
      title: 'Quick Links',
      links: [
        { label: 'Home', href: '/' },
        { label: 'About', href: '/about' },
      ],
    },
  ];

  const contactInfo = [
    {
      icon: Phone,
      title: 'Phone',
      details: ['+1 (555) 123-4567', '+1 (555) 123-4568'],
    },
    {
      icon: Mail,
      title: 'Email',
      details: ['admissions@jits.edu', 'info@jits.edu'],
    },
    {
      icon: MapPin,
      title: 'Address',
      details: ['123 University Avenue', 'City, State 12345'],
    },
    {
      icon: Clock,
      title: 'Office Hours',
      details: ['Mon - Fri: 9:00 AM - 5:00 PM', 'Sat: 10:00 AM - 2:00 PM'],
    },
  ];

  return (
    <div className="min-h-screen">
      <PublicHeader
        navLinks={navLinks}
        onNavClick={(href) => console.log('Navigate:', href)}
        onLoginClick={() => console.log('Login')}
      />

      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-bold mb-4">Contact Us</h1>
          <p className="text-muted-foreground text-lg">
            We're here to help. Reach out to us anytime.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          <div className="lg:col-span-2">
            <ContactForm />
          </div>

          <div className="space-y-6">
            {contactInfo.map((info) => {
              const Icon = info.icon;
              return (
                <Card key={info.title} className="p-6">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-primary/10">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">{info.title}</h3>
                      {info.details.map((detail, index) => (
                        <p key={index} className="text-sm text-muted-foreground">
                          {detail}
                        </p>
                      ))}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>

        <Card className="p-6 bg-muted/30">
          <div className="aspect-video bg-muted rounded-lg flex items-center justify-center">
            <p className="text-muted-foreground">Map will be integrated here</p>
          </div>
        </Card>
      </div>

      <Footer sections={footerSections} onLinkClick={(href) => console.log('Navigate:', href)} />
    </div>
  );
}
