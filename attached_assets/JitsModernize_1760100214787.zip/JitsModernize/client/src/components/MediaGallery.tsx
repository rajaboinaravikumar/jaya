import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  category: string;
}

interface MediaGalleryProps {
  items: GalleryItem[];
  columns?: number;
}

export function MediaGallery({ items, columns = 3 }: MediaGalleryProps) {
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);

  return (
    <>
      <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-${columns} gap-6`}>
        {items.map((item) => (
          <Card
            key={item.id}
            className="overflow-hidden cursor-pointer hover-elevate active-elevate-2 transition-all"
            onClick={() => setSelectedImage(item)}
            data-testid={`card-gallery-${item.id}`}
          >
            <div className="aspect-video relative overflow-hidden">
              <img
                src={item.src}
                alt={item.alt}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="p-4">
              <p className="text-sm text-muted-foreground">{item.category}</p>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={!!selectedImage} onOpenChange={() => setSelectedImage(null)}>
        <DialogContent className="max-w-4xl">
          {selectedImage && (
            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                className="absolute -top-12 right-0"
                onClick={() => setSelectedImage(null)}
                data-testid="button-close-gallery"
              >
                <X className="h-6 w-6" />
              </Button>
              <img
                src={selectedImage.src}
                alt={selectedImage.alt}
                className="w-full h-auto rounded-lg"
              />
              <p className="mt-4 text-center text-muted-foreground">{selectedImage.alt}</p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
