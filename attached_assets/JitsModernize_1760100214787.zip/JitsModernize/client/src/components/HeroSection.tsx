import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface HeroSectionProps {
  title: string;
  subtitle: string;
  primaryCta: string;
  secondaryCta: string;
  backgroundImage: string;
  onPrimaryClick?: () => void;
  onSecondaryClick?: () => void;
}

export function HeroSection({
  title,
  subtitle,
  primaryCta,
  secondaryCta,
  backgroundImage,
  onPrimaryClick,
  onSecondaryClick,
}: HeroSectionProps) {
  return (
    <div className="relative min-h-[70vh] md:min-h-screen flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/40 to-primary/90" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20 text-center text-white">
        <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
          {title}
        </h1>
        <p className="text-xl md:text-2xl mb-12 max-w-3xl mx-auto text-white/95">
          {subtitle}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            size="lg"
            className="bg-white text-primary hover:bg-white/90 border-2 border-white min-h-12 px-8"
            onClick={onPrimaryClick}
            data-testid="button-hero-primary"
          >
            {primaryCta}
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="backdrop-blur-md bg-white/20 border-2 border-white text-white hover:bg-white/30 min-h-12 px-8"
            onClick={onSecondaryClick}
            data-testid="button-hero-secondary"
          >
            {secondaryCta}
          </Button>
        </div>
      </div>
    </div>
  );
}
