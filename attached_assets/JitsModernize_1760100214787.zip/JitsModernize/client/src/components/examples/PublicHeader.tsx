import { PublicHeader } from '../PublicHeader';
import { ThemeProvider } from '../ThemeProvider';

export default function PublicHeaderExample() {
  const navLinks = [
    { label: 'Home', href: '/' },
    {
      label: 'Academics',
      href: '/academics',
      subItems: [
        { label: 'Departments', href: '/departments' },
        { label: 'Programs', href: '/programs' },
        { label: 'Faculty', href: '/faculty' },
      ],
    },
    { label: 'Admissions', href: '/admissions' },
    { label: 'Contact', href: '/contact' },
  ];

  return (
    <ThemeProvider>
      <PublicHeader
        navLinks={navLinks}
        onNavClick={(href) => console.log('Navigate to:', href)}
        onLoginClick={() => console.log('Login clicked')}
      />
    </ThemeProvider>
  );
}
