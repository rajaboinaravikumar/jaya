import { StatsSection } from '../StatsSection';
import { Users, BookOpen, Award, Building } from 'lucide-react';

export default function StatsSectionExample() {
  const stats = [
    {
      value: '15,000+',
      label: 'Students Enrolled',
      icon: <Users className="h-8 w-8" />,
    },
    {
      value: '250+',
      label: 'Expert Faculty',
      icon: <BookOpen className="h-8 w-8" />,
    },
    {
      value: '95%',
      label: 'Placement Rate',
      icon: <Award className="h-8 w-8" />,
    },
    {
      value: '50+',
      label: 'Partner Companies',
      icon: <Building className="h-8 w-8" />,
    },
  ];

  return <StatsSection stats={stats} />;
}
