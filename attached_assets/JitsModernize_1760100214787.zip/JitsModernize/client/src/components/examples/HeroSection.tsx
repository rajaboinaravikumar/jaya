import { HeroSection } from '../HeroSection';
import heroImage from '@assets/stock_images/diverse_university_s_72fb7dec.jpg';

export default function HeroSectionExample() {
  return (
    <HeroSection
      title="Welcome to JITS University"
      subtitle="Empowering minds, shaping futures. Join a community of excellence in education and innovation."
      primaryCta="Apply Now"
      secondaryCta="Virtual Tour"
      backgroundImage={heroImage}
      onPrimaryClick={() => console.log('Apply Now clicked')}
      onSecondaryClick={() => console.log('Virtual Tour clicked')}
    />
  );
}
