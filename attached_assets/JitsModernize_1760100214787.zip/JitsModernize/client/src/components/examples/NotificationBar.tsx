import { NotificationBar } from '../NotificationBar';

export default function NotificationBarExample() {
  return (
    <NotificationBar
      message="Exam results for Fall 2025 semester will be published on October 15th at 10:00 AM"
      type="info"
    />
  );
}
