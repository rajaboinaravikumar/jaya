import { ContactForm } from '../ContactForm';

export default function ContactFormExample() {
  return (
    <div className="p-6 max-w-3xl">
      <ContactForm />
    </div>
  );
}
