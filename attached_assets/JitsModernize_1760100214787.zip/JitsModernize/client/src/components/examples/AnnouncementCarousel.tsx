import { AnnouncementCarousel } from '../AnnouncementCarousel';
import buildingImage from '@assets/stock_images/modern_university_bu_30b47520.jpg';
import classroomImage from '@assets/stock_images/university_classroom_72133f0d.jpg';

export default function AnnouncementCarouselExample() {
  const announcements = [
    {
      id: '1',
      date: 'Oct 10, 2025',
      title: 'Fall 2026 Admissions Now Open',
      description: 'Apply now for Fall 2026 semester. Early bird discounts available until November 30th.',
      image: buildingImage,
      category: 'Admissions',
    },
    {
      id: '2',
      date: 'Oct 8, 2025',
      title: 'Annual Tech Fest 2025',
      description: 'Join us for three days of innovation, workshops, and competitions. Register before Oct 20th.',
      image: classroomImage,
      category: 'Events',
    },
    {
      id: '3',
      date: 'Oct 5, 2025',
      title: 'New AI & Machine Learning Lab Inaugurated',
      description: 'State-of-the-art AI lab with latest GPU systems now available for student research projects.',
      category: 'Infrastructure',
    },
  ];

  return <AnnouncementCarousel announcements={announcements} />;
}
