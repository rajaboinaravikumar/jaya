import { MediaGallery } from '../MediaGallery';
import campusImage1 from '@assets/stock_images/diverse_university_s_f630801d.jpg';
import campusImage2 from '@assets/stock_images/diverse_university_s_e86df4b4.jpg';
import buildingImage1 from '@assets/stock_images/modern_university_bu_30b47520.jpg';
import buildingImage2 from '@assets/stock_images/modern_university_bu_2f8d4032.jpg';
import classroomImage1 from '@assets/stock_images/university_classroom_72133f0d.jpg';
import classroomImage2 from '@assets/stock_images/university_classroom_9ea92665.jpg';

export default function MediaGalleryExample() {
  const items = [
    { id: '1', src: campusImage1, alt: 'Students on campus', category: 'Campus Life' },
    { id: '2', src: buildingImage1, alt: 'Modern university building', category: 'Infrastructure' },
    { id: '3', src: classroomImage1, alt: 'Interactive classroom', category: 'Academics' },
    { id: '4', src: campusImage2, alt: 'Campus activities', category: 'Events' },
    { id: '5', src: buildingImage2, alt: 'University facilities', category: 'Infrastructure' },
    { id: '6', src: classroomImage2, alt: 'Learning environment', category: 'Academics' },
  ];

  return (
    <div className="p-6">
      <h2 className="text-3xl font-semibold mb-8">Campus Gallery</h2>
      <MediaGallery items={items} />
    </div>
  );
}
