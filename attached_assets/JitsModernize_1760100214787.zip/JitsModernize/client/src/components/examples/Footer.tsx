import { Footer } from '../Footer';

export default function FooterExample() {
  const sections = [
    {
      title: 'Quick Links',
      links: [
        { label: 'About Us', href: '/about' },
        { label: 'Admissions', href: '/admissions' },
        { label: 'Careers', href: '/careers' },
      ],
    },
    {
      title: 'Resources',
      links: [
        { label: 'Library', href: '/library' },
        { label: 'Academic Calendar', href: '/calendar' },
        { label: 'Student Portal', href: '/portal' },
      ],
    },
    {
      title: 'Support',
      links: [
        { label: 'Contact Us', href: '/contact' },
        { label: 'FAQ', href: '/faq' },
        { label: 'Support', href: '/support' },
      ],
    },
  ];

  return (
    <Footer
      sections={sections}
      onLinkClick={(href) => console.log('Navigate to:', href)}
    />
  );
}
