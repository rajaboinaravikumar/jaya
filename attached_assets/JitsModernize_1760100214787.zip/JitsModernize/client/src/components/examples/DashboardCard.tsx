import { DashboardCard } from '../DashboardCard';
import { BookOpen } from 'lucide-react';

export default function DashboardCardExample() {
  return (
    <div className="p-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      <DashboardCard
        title="Attendance"
        value="92.5%"
        icon={BookOpen}
        description="This semester"
        accentColor="bg-success"
      />
      <DashboardCard
        title="Current GPA"
        value="3.8"
        icon={BookOpen}
        trend={{ value: '+0.2 from last sem', isPositive: true }}
        accentColor="bg-primary"
      />
      <DashboardCard
        title="Pending Assignments"
        value="3"
        icon={BookOpen}
        description="Due this week"
        accentColor="bg-warning"
      />
    </div>
  );
}
