import { QuickLinks } from '../QuickLinks';
import { GraduationCap, FileText, Calendar, Users } from 'lucide-react';

export default function QuickLinksExample() {
  const links = [
    {
      icon: GraduationCap,
      title: 'Admissions',
      description: 'Apply online and track your application status',
      href: '/admissions',
    },
    {
      icon: FileText,
      title: 'Results',
      description: 'View exam results and academic performance',
      href: '/results',
    },
    {
      icon: Calendar,
      title: 'Academic Calendar',
      description: 'Stay updated with important dates',
      href: '/calendar',
    },
    {
      icon: Users,
      title: 'Alumni',
      description: 'Connect with our alumni network',
      href: '/alumni',
    },
  ];

  return (
    <QuickLinks
      links={links}
      onLinkClick={(href) => console.log('Navigate to:', href)}
    />
  );
}
