import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface Announcement {
  id: string;
  date: string;
  title: string;
  description: string;
  image?: string;
  category: string;
}

interface AnnouncementCarouselProps {
  announcements: Announcement[];
  autoRotate?: boolean;
  interval?: number;
}

export function AnnouncementCarousel({
  announcements,
  autoRotate = true,
  interval = 5000,
}: AnnouncementCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!autoRotate || announcements.length <= 1) return;

    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % announcements.length);
    }, interval);

    return () => clearInterval(timer);
  }, [autoRotate, interval, announcements.length]);

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % announcements.length);
  };

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + announcements.length) % announcements.length);
  };

  if (announcements.length === 0) return null;

  return (
    <div className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-semibold">Latest Announcements</h2>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              onClick={goToPrevious}
              data-testid="button-carousel-prev"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={goToNext}
              data-testid="button-carousel-next"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="relative overflow-hidden">
          <div
            className="flex transition-transform duration-500 ease-out"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {announcements.map((announcement) => (
              <div key={announcement.id} className="w-full flex-shrink-0">
                <Card className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    {announcement.image && (
                      <div className="md:w-1/3">
                        <img
                          src={announcement.image}
                          alt={announcement.title}
                          className="w-full h-48 object-cover rounded-lg"
                        />
                      </div>
                    )}
                    <div className={announcement.image ? "md:w-2/3" : "w-full"}>
                      <div className="flex items-center gap-3 mb-4">
                        <Badge variant="secondary">{announcement.category}</Badge>
                        <span className="text-sm text-muted-foreground">{announcement.date}</span>
                      </div>
                      <h3 className="text-2xl font-semibold mb-3">{announcement.title}</h3>
                      <p className="text-muted-foreground">{announcement.description}</p>
                    </div>
                  </div>
                </Card>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center mt-6 gap-2">
          {announcements.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`h-2 rounded-full transition-all ${
                index === currentIndex ? "w-8 bg-primary" : "w-2 bg-muted-foreground/30"
              }`}
              data-testid={`button-carousel-dot-${index}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
