import { useState } from "react";
import { X, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";

interface NotificationBarProps {
  message: string;
  type?: "info" | "warning" | "success";
  dismissible?: boolean;
}

export function NotificationBar({ message, type = "info", dismissible = true }: NotificationBarProps) {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  const bgColors = {
    info: "bg-info/10 border-info/20",
    warning: "bg-warning/10 border-warning/20",
    success: "bg-success/10 border-success/20",
  };

  const textColors = {
    info: "text-info-foreground",
    warning: "text-warning-foreground",
    success: "text-success-foreground",
  };

  return (
    <div className={`${bgColors[type]} border-b px-6 py-3`}>
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1">
          <Bell className={`h-5 w-5 ${textColors[type]}`} />
          <p className={`text-sm md:text-base ${textColors[type]}`}>{message}</p>
        </div>
        {dismissible && (
          <Button
            variant="ghost"
            size="icon"
            className="flex-shrink-0"
            onClick={() => setIsVisible(false)}
            data-testid="button-notification-dismiss"
          >
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>
    </div>
  );
}
