import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  accentColor?: string;
}

export function DashboardCard({
  title,
  value,
  icon: Icon,
  description,
  trend,
  accentColor = "bg-primary",
}: DashboardCardProps) {
  return (
    <Card className="p-6 relative overflow-hidden">
      <div className={`absolute top-0 right-0 h-full w-1 ${accentColor}`} />
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <p className="text-sm text-muted-foreground mb-1">{title}</p>
          <h3 className="text-3xl font-bold mb-2" data-testid="text-card-value">{value}</h3>
          {description && <p className="text-sm text-muted-foreground">{description}</p>}
          {trend && (
            <div className={`text-sm mt-2 ${trend.isPositive ? 'text-success' : 'text-destructive'}`}>
              {trend.isPositive ? '↑' : '↓'} {trend.value}
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${accentColor}/10`}>
          <Icon className={`h-6 w-6 ${accentColor.replace('bg-', 'text-')}`} />
        </div>
      </div>
    </Card>
  );
}
