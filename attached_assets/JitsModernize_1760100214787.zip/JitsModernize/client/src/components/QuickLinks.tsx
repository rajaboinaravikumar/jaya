import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { ArrowRight } from "lucide-react";

interface QuickLink {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

interface QuickLinksProps {
  links: QuickLink[];
  onLinkClick?: (href: string) => void;
}

export function QuickLinks({ links, onLinkClick }: QuickLinksProps) {
  return (
    <div className="py-16 md:py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-semibold mb-4">Quick Access</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Everything you need, just a click away
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {links.map((link, index) => {
            const Icon = link.icon;
            return (
              <Card
                key={index}
                className="p-6 hover-elevate active-elevate-2 cursor-pointer transition-all"
                onClick={() => onLinkClick?.(link.href)}
                data-testid={`card-quicklink-${index}`}
              >
                <div className="flex flex-col items-center text-center space-y-4">
                  <div className="p-4 rounded-xl bg-primary/10">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-medium">{link.title}</h3>
                  <p className="text-muted-foreground text-sm">{link.description}</p>
                  <div className="flex items-center text-primary text-sm font-medium pt-2">
                    Learn more <ArrowRight className="ml-1 h-4 w-4" />
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}
