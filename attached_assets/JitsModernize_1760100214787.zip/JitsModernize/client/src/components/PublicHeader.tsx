import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, ChevronDown } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface NavLink {
  label: string;
  href: string;
  subItems?: { label: string; href: string }[];
}

interface PublicHeaderProps {
  navLinks: NavLink[];
  onNavClick?: (href: string) => void;
  onLoginClick?: () => void;
}

export function PublicHeader({ navLinks, onNavClick, onLoginClick }: PublicHeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-8">
            <h1 className="text-xl font-bold text-primary">JITS University</h1>
            
            <nav className="hidden md:flex items-center gap-6">
              {navLinks.map((link) => (
                link.subItems ? (
                  <DropdownMenu key={link.label}>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="gap-1" data-testid={`nav-${link.label.toLowerCase()}`}>
                        {link.label}
                        <ChevronDown className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                      {link.subItems.map((item) => (
                        <DropdownMenuItem
                          key={item.href}
                          onClick={() => onNavClick?.(item.href)}
                          data-testid={`nav-${item.label.toLowerCase()}`}
                        >
                          {item.label}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Button
                    key={link.href}
                    variant="ghost"
                    onClick={() => onNavClick?.(link.href)}
                    data-testid={`nav-${link.label.toLowerCase()}`}
                  >
                    {link.label}
                  </Button>
                )
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button onClick={onLoginClick} data-testid="button-login">
              Login
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              data-testid="button-mobile-menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            {navLinks.map((link) => (
              <div key={link.href}>
                <Button
                  variant="ghost"
                  className="w-full justify-start"
                  onClick={() => {
                    onNavClick?.(link.href);
                    setMobileMenuOpen(false);
                  }}
                >
                  {link.label}
                </Button>
                {link.subItems && (
                  <div className="pl-4 space-y-1">
                    {link.subItems.map((item) => (
                      <Button
                        key={item.href}
                        variant="ghost"
                        className="w-full justify-start text-sm"
                        onClick={() => {
                          onNavClick?.(item.href);
                          setMobileMenuOpen(false);
                        }}
                      >
                        {item.label}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>
        )}
      </div>
    </header>
  );
}
