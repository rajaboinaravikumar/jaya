# JITS University Portal - Comprehensive Design Guidelines

## Design Approach

**Hybrid Strategy**: Material Design foundation for portal functionality + elevated marketing aesthetics for public pages

**Justification**: University portals require robust, data-dense interfaces (dashboards, forms, tables) while public-facing pages need visual appeal to attract prospective students. Material Design provides excellent patterns for complex information architecture while allowing creative freedom for hero sections and landing pages.

---

## Core Design Elements

### A. Color Palette

**Primary Brand Colors**:
- Primary: 210 85% 45% (Deep University Blue - conveys trust, education)
- Primary Hover: 210 85% 38%
- Secondary: 200 15% 25% (Slate - professional, neutral)

**Functional Colors**:
- Success: 142 71% 45% (Academic achievement green)
- Warning: 38 92% 50% (Notification amber)
- Error: 0 84% 60% (Alert red)
- Info: 199 89% 48% (Information cyan)

**Background System**:
- Light Mode: 0 0% 100% (white), 220 13% 97% (off-white)
- Dark Mode: 222 47% 11% (deep navy), 215 28% 17% (card surface)
- Subtle borders: Light 220 13% 91% / Dark 215 20% 25%

### B. Typography

**Font Families**:
- Headings: 'Inter' (CDN: Google Fonts) - weights 600, 700, 800
- Body: 'Inter' (CDN: Google Fonts) - weights 400, 500, 600
- Data/Tables: 'JetBrains Mono' - weight 400 for tabular numbers

**Scale**:
- Hero Display: text-6xl to text-7xl (60-72px), font-bold
- Page Titles: text-4xl (36px), font-semibold
- Section Headers: text-2xl to text-3xl (24-30px), font-semibold
- Card Titles: text-xl (20px), font-medium
- Body: text-base (16px), font-normal
- Captions/Meta: text-sm (14px)

### C. Layout System

**Spacing Primitives**: Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Micro spacing (buttons, badges): p-2, p-4
- Component padding: p-6, p-8
- Section spacing: py-12, py-16, py-20
- Container gaps: gap-4, gap-6, gap-8

**Grid System**:
- Dashboard cards: grid with gap-6, responsive cols (1/2/3)
- Forms: max-w-2xl centered, two-column on desktop
- Content: max-w-7xl with px-6 to px-8 horizontal padding
- Tables: full-width within max-w-7xl containers

### D. Component Library

**Navigation**:
- Top Nav: Sticky header with logo left, primary links center, user profile/notifications right
- Mega Menu: Dropdown for Academics/Admissions with 3-column layout showing departments
- Mobile: Slide-in drawer with accordion sub-menus
- Dashboard Sidebar: Fixed left panel (280px) with collapsible sections, icon + label

**Cards & Containers**:
- Dashboard Cards: White/dark surface, rounded-xl, shadow-sm, border subtle
- Stat Cards: Prominent number (text-3xl), label below, icon top-right, colored accent strip
- Feature Cards: Icon top, title (text-xl), description (text-gray-600), optional action link
- Elevated Cards: shadow-md on hover, transition-all duration-200

**Forms & Inputs**:
- Input Fields: border-2, rounded-lg, px-4 py-3, focus:ring-2 focus:ring-primary
- Labels: text-sm font-medium, mb-2, text-gray-700 dark:text-gray-300
- Dropdowns: Custom styled with Heroicons chevron-down
- File Upload: Drag-drop zone with dashed border, upload icon, browse button
- Multi-step Forms: Progress indicator top, numbered steps, next/back navigation

**Data Display**:
- Tables: Striped rows, hover highlight, sticky header, compact padding (px-4 py-3)
- Results Cards: Student photo left, details center, grade/status right with colored badge
- Timeline: Vertical line left, circular markers, card content right
- Calendar: Grid view with event dots, modal details on click

**Buttons & Actions**:
- Primary: bg-primary text-white, px-6 py-2.5, rounded-lg, font-medium
- Secondary: border-2 border-primary text-primary, hover:bg-primary/10
- Outline on Images: backdrop-blur-md bg-white/20 border-2 border-white text-white
- Icon Buttons: Circular, p-2, hover:bg-gray-100 dark:hover:bg-gray-800
- FAB (Floating): Fixed bottom-right, rounded-full, shadow-lg, primary color

**Notifications & Alerts**:
- Banner: Full-width, colored left border (4px), icon left, close button right
- Toast: Bottom-right, slide-in animation, auto-dismiss, icon + message
- Badge: Absolute top-right on bell icon, red dot or number, pulsing animation
- Announcement Bar: Top of page, marquee or carousel, dismissible

**Overlays**:
- Modal: Centered, max-w-2xl, backdrop-blur, slide-up animation, close X top-right
- Drawer: Slide from right (400px), full-height, for filters/details
- Dropdown Menu: Rounded-lg, shadow-lg, arrow pointer, positioned below trigger

### E. Animations

**Strategic Use Only**:
- Page transitions: Fade-in content (opacity 0 to 1, 300ms)
- Card hover: Slight lift (translateY -2px) + shadow increase
- Success states: Checkmark bounce animation on form submit
- Loading: Skeleton screens (pulse animation) for data tables/cards
- NO scroll-triggered animations, NO parallax, NO complex transitions

---

## Page-Specific Guidelines

### Public Homepage
**Hero Section**:
- Full-width background image (students on campus, vibrant, professional)
- Overlay: gradient from transparent to primary/90% bottom
- Content: Large heading (text-6xl), subheading, two CTAs (Apply Now + Virtual Tour)
- Height: min-h-screen on desktop, min-h-[70vh] on mobile
- Buttons: Primary solid + Secondary outline with backdrop-blur

**Quick Links Section**:
- 4-column grid (2 on tablet, 1 on mobile)
- Icon cards: Large Heroicon top, title, brief description, arrow link
- Spacing: py-20, gap-8 between cards

**Announcements Carousel**:
- 3 visible cards, auto-rotate every 5s, manual controls
- Card: Date badge top-left, image thumbnail left, title + snippet right
- Indicators: Dots below, active highlighted

**Stats/Achievements**:
- 4-column layout: Number (text-5xl, colored), label below
- Background: Subtle gradient or solid color block
- Counters: Animate on scroll into view

### Student Dashboard
**Layout**: Sidebar left (280px), main content area right, top header with search/notifications

**Widget Grid**:
- Attendance Card: Circular progress (percentage), color-coded status, last 7 days mini-calendar
- Results Card: Latest grades table, semester GPA prominent, "View All" link
- Assignments: List with due date, status badge (pending/submitted), upload button
- Fee Status: Amount due, payment history link, "Pay Now" button if pending
- Timetable: Weekly grid view, current class highlighted

**Data Presentation**:
- Use Material Design elevated surfaces (level 1-3)
- Icons from Heroicons for consistent visual language
- Color-coded status indicators (green=complete, amber=pending, red=overdue)

### Admissions Portal
**Application Flow**:
- Multi-step form: Personal → Academic → Documents → Payment → Review
- Progress bar: Filled segments with checkmarks for completed steps
- Document Upload: Grid of upload zones, thumbnail preview on upload, remove option
- Payment Integration: Stripe checkout modal, amount summary, secure badge

### Media Gallery
**Layout**: Masonry grid (Pinterest-style) for photos, video grid separate
**Filters**: Dropdown for category (Events/Campus/Academic), year selector, search
**Lightbox**: Full-screen overlay on click, navigation arrows, caption bottom, close X

---

## Images

**Hero Image**: Wide-angle campus shot with students, bright daytime, diverse group, professional quality. Full-width background, 1920x1080 minimum.

**Dashboard Icons**: Use Heroicons for all dashboard elements - academic-cap, calendar, chart-bar, document-text, bell, user-circle.

**Gallery Placeholders**: Actual campus photos, events, classrooms. Avoid stock photos. Aspect ratio 16:9 for consistency.

**Profile Avatars**: Circular, 40px dashboard, 120px profile page, placeholder initials if no photo.

---

## Responsive Breakpoints

- Mobile: base (single column, stacked nav, touch-friendly 44px tap targets)
- Tablet: md: (2-column grids, hamburger menu)
- Desktop: lg: (3-4 column grids, full sidebar, mega menu)
- Wide: xl: (max-w-7xl containers, more whitespace)